<!DOCTYPE html>
<html>
    <head>
    <link rel="canonical" href="https://getbootstrap.com/docs/3.3/examples/navbar/">    
    <title>document</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">

    </head>
<body>
<nav class="navbar navbar-default">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Aplikasi Penerimaan Siswa Baru</a>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li class="active"><a href="form.php">Tambah data siswa</a></li>
              <li><a href="menu.php">Beranda </a></li>
              <li><a href="data.php">Siswa yang diterima </a></li>
              <li><a href="logout.php">Logout</a></li>
              
                </ul>
              </li>
            </ul>
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
      </nav>
      <center>
        <div class = "panel-body">
        <a href="form.php" class = "btn btn-primary" style = "margin-bottom : 10px"> Tambah Data</a>
        <br>
        <table border="1" class = "table table bordered table-striped">
            <br><tr>
                <th>NO</th>
                <th>id</th>
                <th >Nama</th>
                <th >askol</th>
                <th >alamat</th>
                <th colspan="3">Aksi</th>
            </tr></center>
            <?php
include '../database.php';
$dosen = new Dosen();
$no = 1;
// var_dump($dosen->index());
foreach ($dosen->index() as $data) {
    ?>
                <tr>
                    <td ><?php echo $no++; ?></td>
                    <td ><?php echo $data['id']; ?></td>
                    <td ><?php echo $data['nama']; ?></td>
                    <td ><?php echo $data['askol']; ?></td>
                    <td ><?php echo $data['alamat']; ?></td>


                    <td>
                        <a href="show.php?id=<?php echo $data['id']; ?>">show</a>
                    </td>
                    <td>
                        <a href="edit.php?id=<?php echo $data['id']; ?>">edit</a>
                    </td>
                    <td>
                        <form action="proses.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
                <input type="hidden" name="aksi" value="delete">
            <button type="submit" name="save" onclick="return confirm('Apakah anda yakin mau menghapus
            data ini?')">Delete
            </button>
              </form>
                    </td>
                </tr>
                <?php
}?>
        </table>
    </fieldset>
</body>
    </html>