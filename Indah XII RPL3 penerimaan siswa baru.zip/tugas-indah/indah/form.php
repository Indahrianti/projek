<html>
    <head>
    <link rel="canonical" href="https://getbootstrap.com/docs/3.3/examples/navbar/">

        <title>document</title>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    </head>
    <body>
        <div class = "panel panel-warning">
        <div class = "panel-heading">
        <h3>Tambah Data</h3>
</div>
</div>
        <div class = "panel-body">
        <form action="proses.php" method="post">
        <input type="hidden" name="aksi" value="create">
        <table>
        <tr>
                    <td>Nama</td>
                    <td>
                        <input type = "text" name = "nama" class = "form-control" required>
        </td>
        </tr>
        <tr>
                    <td>Asal Sekolah</td>
                    <td>
                        <input type = "text" name = "askol" class = "form-control" required>
        </td>
        </tr>
        <tr>
                    <td>Alamat</td>
                    <td>
                        <input type = "text" name = "alamat" class = "form-control" required>
        </td>
        </tr>
       
        <tr>
            <td>
                <input type = "submit" name = "save" class = "btn btn-danger" value="Simpan">
        </td>
        </tr>
        </table>
    </form>
        </fieldset>
    </body>
</html>
