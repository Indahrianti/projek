<html>
    <!DOCTYPE html>
<html>
    <head> <link rel="canonical" href="https://getbootstrap.com/docs/3.3/examples/navbar/">    
        <title>document</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet"></head>
     
<body>
<nav class="navbar navbar-default">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li class="active"><a href="form.php">Tambah data siswa</a></li>
              <li><a href="menu.php">Beranda </a></li>
              <li><a href="data.php">Siswa yang diterima </a></li>
              <li><a href="logout.php">Logout</a></li>
              
                </ul>
              </li>
            </ul>
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
      </nav>

<fieldset><center>
    
        <legend><h2>Data Siswa Yang Diterima</h2></legend>
        
       <table border="1" class = "table table bordered table-striped"><br>
            <tr>
                <th>NO</th>
                <th>id</th>
                <th>Nama</th>
                <th>askol</th>
                

            </tr></center>
            <?php
include '../database.php';
$dosen = new Dosen();
$no = 1;
// var_dump($dosen->index());
foreach ($dosen->index() as $data) {
    ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $data['id']; ?></td>
                    <td><?php echo $data['nama']; ?></td>
                    <td><?php echo $data['askol']; ?></td>
                   

                </tr>
                <?php
}?>
        </table>
    </fieldset>
</body>
    </html>
</html>
