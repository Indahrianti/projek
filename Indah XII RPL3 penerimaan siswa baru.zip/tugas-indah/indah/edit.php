<html>
    <head>
    <link rel="canonical" href="https://getbootstrap.com/docs/3.3/examples/navbar/">
        <title>d</title>
        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    </head>
      
    <body>
    <div class = "panel panel-warning">
        <div class = "panel-heading">
        <h3>Edit  siswa</h3>
        </div>
</div>
        <?php
include '../database.php';
$dosen = new Dosen();
foreach ($dosen->edit($_GET['id']) as $data) {
    $id = $data['id'];
    $nama = $data['nama'];
    $askol = @$_POST['askol'];
    $alamat = @$_POST['alamat'];

}
?>
        <fieldset>
        <div class = "panel-body">
        <form action="proses.php" method="post">
            <form action="proses.php" method="Post">
                <input type="hidden" name="aksi" value="update">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <table>

                    <tr>
                        <th>Nama</th>
                        <td><input type="text" name="nama" class = "form-control" value="<?php echo $nama; ?>" required> </td>
                    </tr>

                     <tr>
                        <th>AsalSekolah</th>
                        <td><input type="text" name="askol" class = "form-control" value="<?php echo $askol; ?>" required> </td>
                    </tr>
                     <tr>
                        <th>Alamat</th>
                        <td><input type="text" name="alamat" class = "form-control" value="<?php echo $alamat; ?>" required> </td>
                    </tr>
                    <tr>
                        <th><input type="submit" name="save" class = "btn btn-danger" value="simpan"> </th>
                    </tr>
                </table>
            </form>
        </fieldset>
    </body>
</html>