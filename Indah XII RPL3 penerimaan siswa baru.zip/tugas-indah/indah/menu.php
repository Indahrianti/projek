<html>
<head>
<link rel="canonical" href="https://getbootstrap.com/docs/3.3/examples/navbar/">
<title>sa</title>
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
   <form action="" method="">
   <nav class="navbar navbar-default">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
</button>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li class="active"><a href="menu.php">Menu</a></li>
              <li><a href="form.php">Form Input</a></li>
              <li><a href="data.php">Data Siswa Yang Di Terima</a></li>
              <li><a href="logout.php">Logout</a></li>
            </ul>
          </div><!--/.nav-collapse -->
        </div><!--/.container-fluid -->
      </nav>
      <div class="container">
      <div class = "panel panel-primary">
          <div class = "panel-heading">
              <h3 class = "panel-title">Profil Sekolah</h3>
</div>
</div>

       <h1 align="center">Penerimaan Siswa Baru<br>SMK ASSALAAM BANDUNG</h1>
<center>
      <br>
      <img src = "bg.jpg" align = "center" height="200px" width="500px"></center>
      <br><h4>PROFIL</h4>
      SMK Assalaam merupakan sekolah kejuruan dengan kompetensi keahlian
      teknik kendaraan ringan (roda empat) plus sepeda motor dalam proses pendidikan pelatihan.
      Peka terhadap perubahan perkembangan teknologi baru dan tuntutan kebutuhan pasar kerja,
      agar lulusannya siap menghadapi perubahan.</br>
      <h4>KEUNGGULAN</h4>
      1. Program pembelajaran disusun berdasarkan standar Nasional dan dikembangkan berdasarkan
      kebutuhan industri serta  bekerjasama dengan DU/DI (Dunia Usaha/Dunia Industri)</br>
<br>2. Menghasilkan lulusan yang siap bekerja,memiliki mentalitas kerja yang tangguh,
dan memiliki keterampilan ganda (jurusan otomotif : Mobil + Motor, jurusan  RPL : programer + teknisi)
<br>3. Tenaga pendidik berasal dari lulusan perguruan-perguruan tinggi terkemuka, dan pelaku Industri
<br>4. Setiap pelajaran praktek/paket keahlian dilaksanakan dengan menggunakan sistem blok, dengan 3 guru pengajar.
<br>5. Ujian Kompetensi diselenggarakan secara mandiri, menggunakan kendaraan dan alat yang mutakhir .</br>


   </form>
   
</body>
</html>
