<?php
 $connect = mysqli_connect("localhost","root","","tugas-projek");

 if (!$connect) {
     echo "Koneksi ke MySQL Gagal";
 }
 ?>
