<!DOCTYPE html>
<html>
    <head>
    <link rel="canonical" href="https://getbootstrap.com/docs/3.3/examples/navbar/">
<title>document</title>
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet"></head>
  
    <body>
    <div class = "panel panel-warning">
        <div class = "panel-heading">
<h3>Daftar  siswa</h3>
        </div>
</div>
       <?php
include '../database.php';
$dosen = new Dosen();
foreach ($dosen->show($_GET['id']) as $data) {
    $id = $data['id'];
    $nama = $data['nama'];
    $askol = $data['askol'];
    $alamat = $data['alamat'];

}
?>

       <fieldset>
           <nav class="navbar navbar-default">
        <div class="container-fluid">
          <ul class="nav navbar-nav">
             <li class="active"><a href="menu.php">Beranda |</a></li>
             <li><a href="form.php">Form Siswa |</a></li>
           <li><a href="index.php">kembali ke index |</a></li>

            <li><a href=".php">Data Siswa Yang Diterima |</a></li>
          </ul>
        </div>
      </nav>

      <div class = "panel-body">

           <table>
               <tr>
                   <td>id</td><td>:</td>
                   <td><input type="number" name="id" class = "form-control" value="<?php echo $id; ?>" readonly></td>
               </tr>
                <tr>
                   <td>Nama</td><td>:</td>
                   <td><input type="text" name="nama" class = "form-control" value="<?php echo $nama; ?>" readonly></td>
               </tr>

                <tr>
                   <td>Asal Sekolah</td><td>:</td>
                   <td><input type="text" name="askol" class = "form-control" value="<?php echo $askol; ?>" readonly></td>
               </tr>
               <tr>
                   <td>Alamat</td><td>:</td>
                   <td><input type="text" name="alamat" class = "form-control" value="<?php echo $alamat; ?>" readonly></td>
               </tr>


           </table>
       </fieldset>
    </body>
</html>