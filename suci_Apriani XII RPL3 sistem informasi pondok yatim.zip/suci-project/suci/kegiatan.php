<!DOCTYPE html>
<html lang="en">
<head>
  <title>Panti asuhan</title>
</head>
<body>
  <fieldset><h1 border="1" style="padding: 20px; background-color: pink;">
  <center>PANTI YATIM INDONESIA</center></h1></fieldset>
  <center>
    <fieldset>
    <h1 border="1" style="padding: 10px; background-color: pink;">
  <nav class="navbar navbar-default">
        <div class="container-fluid">
          <ul class="nav navbar-nav">
            <li class="active"><a href="profil.php">Beranda</a></li>
            <li><a href="kegiatan.php">Kegiatan</a></li>
            <li><a href="anak_asuh.php">Anak Asuh</a></li>
            <li><a href="galeri_poto.php">Galeri</a></li>
            <li><a href="buku_tamu.php">Buku Tamu</a></li>
            <li><a href="donasi.php">Donasi</a></li>
            <li><a href="kontak.php">kontak</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div>
      </nav>
  </center>
  <center><br><h1>KEGIATAN BAGI AMAL DAN SODAKOH
      <br> <img src = "satu.jpeg"  width="400x" right="200px"></br>
      <br><h1>SEMBAKO KEMERDEKAAN<h1>
      <br><img src = "dua.jpeg"  width="400px" right="200px"></br>
      <br><h1>BANTUAN ANAK ANAK<h1>
      <br><img src = "tiga.jpeg"  width="400px" right="200px"></br>
      <br><h1>KUNJUNGAN ANAK YATIM<h1>
      <br><img src = "delapan.jpeg"  width="400px" right="200px"></br>
      <br><h1>BERKUMPUL BERSAMA<h1>
      <br><img src = "lima.jpg"  width="400px" right="200px"></br>
<h1 <center>
</center>
<style type="text/css">
    a{text-decoration: none; font-size: 20px;font-family: sans-serif;padding: 14px 10px}
    ul{padding: 14px}
    li{list-style: none; display: inline;}
    li a{background: salmon; color:brown;}
</style>
</fieldset>
</body>
</html>