<?php
 $connect = mysqli_connect("localhost","root","","yatim");

 if (!$connect) {
     echo "Koneksi ke MySQL Gagal";
 }
 ?>
