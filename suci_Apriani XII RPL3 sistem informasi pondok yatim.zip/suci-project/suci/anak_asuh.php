<!DOCTYPE html>
<html>
<head>
   <title>Tabel di HTML</title>
</head>
<body>
<fieldset><h1 border="1" style="padding: 20px; background-color: pink;">
  <center>PANTI YATIM INDONESIA</center></h1></fieldset>
  <center>
    <fieldset
    <h1 border="1" style="padding: 100px; background-color: pink;">
  <nav class="navbar navbar-default">
        <div class="container-fluid">
          <ul class="nav navbar-nav">
            <li class="active"><a href="profil.php">Beranda</a></li>
            <li><a href="kegiatan.php">Kegiatan</a></li>
            <li><a href="anak_asuh.php">Anak Asuh</a></li>
            <li><a href="galeri_poto.php">Galeri</a></li>
            <li><a href="buku_tamu.php">Buku Tamu</a></li>
            <li><a href="donasi.php">Donasi</a></li>
            <li><a href="kontak.php">kontak</a></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </div>
      </nav>
<h1>DATA ANAK BINAAN RUMAH YATIM</h1>
<table border='1' width='900px'>
	<tr>
		<th>No</th>
		<th>Nama</th>
		<th>jenis kelamin</th>
        <th>Asal Alamat Rumah</th>
        <th>status</th>
    </tr>
    <tr>
        <td>1</td>
		<td>Aris Samsudin</td>
		<td>laki-laki</td>
        <td>cilisung</td>
        <td>SMP/MTS/sederajat</td>
    </tr>
	<tr>
        <td>2</td>
		<td>Taufik Hidayat</td>
		<td>lali-laki</td>
        <td>cikampek</td>
        <td>SMP/MTS/sederajat</td>
    </tr>
    <tr>
        <td>3</td>
		<td>Mitahul Zannah</td>
        <td>perempuan</td>
        <td>bandung</td>
        <td>SMP/MTS/sederajat</td>
    </tr>
    <tr>
        <td>4</td>
		<td>Sinta Yasmin</td>
		<td>perempuan</td>
        <td>jakarta</td>
        <td>SMP/MTS/sederajat</td>
    </tr>
    <tr>
        <td>5</td>
		<td>Indri Wulandari</td>
		<td>perempuan</td>
        <td>Jateng</td>
        <td>SMP/MTS/sederajat</td>
    </tr>
</body>
 </fieldset>
<style type="text/css">
    a{text-decoration: none; font-size: 20px;font-family: sans-serif;padding: 14px 10px}
    ul{padding: 30px}
    li{list-style: none; display: inline;}
    li a{background: salmon; color:brown;}
</style>
</html>