<!DOCTYPE html>
<html lang="en">
<head>
  <title>Panti asuhan</title>
</head>
<body>
  <fieldset><h1 border="1" style="padding: 20px; background-color: pink;">
  <center>PANTI YATIM INDONESIA</center></h1></fieldset>
  <center>
    <fieldset>
    <h3 border="1" style="padding: 10px; background-color: pink;">
  <nav class="navbar navbar-default">
        <div class="container-fluid">
          <ul class="nav navbar-nav">
            <li class="active"><a href="profil.php">Beranda</a></li>
            <li><a href="kegiatan.php">Kegiatan</a></li>
            <li><a href="anak_asuh.php">Anak Asuh</a></li>
            <li><a href="galeri_poto.php">Galeri</a></li>
            <li><a href="buku_tamu.php">Buku Tamu</a></li>
            <li><a href="donasi.php">Donasi</a></li>
            <li><a href="kontak.php">kontak</a></li>
          </ul>
        </div>
      </nav>
      <br>VISI</br>
Terwujudnya Lembaga Amil Zakat Nasional yang unggul, amanah dan berperan aktif dalam pembangunan
sumberdaya manusia berdasarkan pemberdayaan
<br><br>MISI</br>
Mengorganisasi sumber daya dan melakukan pemberdayaan potensi umat untuk kesejahtraan kemanusiaan, pendidikan, kesehatan dan dakwah
Mengoptimalisasi pengelolaan dana ziswaf (zakat, infaq, sedekah, wakaf) dan kemanusiaan sesuai syari’at islam dan undang-undang yang berlaku
Bersinergi membangun program pemberdayaan dan pendayagunaan dengan menguatkan jaringan filantropi Nasional dan Internasional
</br><br>Panti Yatim Indonesia</br>
Untuk Informasi Mengenai Panti Yatim Indonesia Silahkan Hubungi :
<br>Kantor Pusat : Jl. Sauyunan Raya I No. 14 Bandung (022)- 540 1334
<br>Kantor Management : Jl. Holis No.6, Cibuntu, Kec. Bandung Kulon, Kota Bandung, Jawa Barat 40212
<br>Call Center         : 081-2222-44-222
<br>SMS Center / Whatsapp Center       : 081-2211-85-555
<br>Mail Center        : mail@pantiyatim.or.id </br>
  </center>
<h3 <center>
</body>
<style type="text/css">
    a{text-decoration: none; font-size: 20px;font-family: sans-serif;padding: 14px 10px}
    ul{padding: 14px}
    li{list-style: none; display: inline;}
    li a{background: salmon; border-radius:10px; color:brown;}
</style>
</fieldset>
</html>